Instructions for (infamous) Windows

Copy (or overwrite) the following library files in the \lib directory of your compiler (if needed)

Copy glut.dll into your 'C:\Windows\System32' folder (If you're using Windows 7 64-bit, you'll need to copy this file into 'C:\Windows\sysWOW64').

