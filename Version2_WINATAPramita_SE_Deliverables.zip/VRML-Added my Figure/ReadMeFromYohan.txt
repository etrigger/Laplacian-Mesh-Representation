Unzip the file in this directory or update the path you consider in the main.cpp file. 

As an example ready to go, the David model is set by default in the Qt and code blocks Projects.

Careful, these files might be too big to be processed by your algorithm, so do not hesitate to find some other on the internet...